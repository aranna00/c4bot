////
//// Created by aran on 22-3-2018.
////
//
//#ifndef C4BOT_1_C4BOTAB_H
//#define C4BOT_1_C4BOTAB_H
//
//#include "c4.h"
//
//int maxPly = 5;
//struct AB{
//    Move move;
//    int score;
//};
//Player otherPlayer(Player player);
//
//#endif //C4BOT_1_C4BOTAB_H
